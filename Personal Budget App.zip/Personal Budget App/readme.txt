****Please use these two python files called GUI.py and budget_functions.py in the same project.****
****Please do not forget to import the necessary packages that are mentioned in the code.****